/*
** Watch_Face_Editor tool v 17.1
** watchface js version v2.1.1
** CyberHUD Watchface for Amazfit Active
*/

try {
(() => {
    //start of ignored block
    const __$$app$$__ = __$$hmAppManager$$__.currentApp;
    function getApp() {
        return __$$app$$__.app;
    }
    function getCurrentPage() {
        return __$$app$$__.current && __$$app$$__.current.module;
    }
    const __$$module$$__ = __$$app$$__.current;
    const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
    const {px} = __$$app$$__.__globals__;
    const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_CyberHUD');
    //end of ignored block

    //dynamic modify start
    let normal_background_bg_img = ''
    let normal_date_img_date_week_img = ''
    let normal_date_img_date_month_img = ''
    let normal_date_img_date_day = ''
    let normal_weather_image_progress_img_level = ''
    let normal_weather_text_img = ''
    let normal_digital_clock_img_time = ''
    let normal_digital_clock_img_time_AmPm = ''
    let normal_step_current_text_img = ''
    let normal_step_progress_img = ''
    let normal_battery_text_text_img = ''
    let normal_battery_progress_img = ''
    let normal_heart_text_img = ''
    let normal_calorie_text_img = ''
    let normal_distance_text_img = ''
    let idle_digital_clock_img_time = ''
    let idle_digital_clock_img_time_AmPm = ''
    //dynamic modify end

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
        init_view() {
            //dynamic modify start

            console.log('Watch_Face.ScreenNormal');

            // 1. Background
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                src: 'WP_01.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // 2. Weekday
            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                x: 58,
                y: 24,
                week_en: ["0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png"],
                week_tc: ["0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png"],
                week_sc: ["0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png"],
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // 3. Month
            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
                month_startX: 84,
                month_startY: 48,
                month_en_array: ["0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png"],
                month_tc_array: ["0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png"],
                month_sc_array: ["0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png"],
                month_is_character: true,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // 4. Day of Month
            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
                day_startX: 58,
                day_startY: 48,
                day_en_array: ["0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png"],
                day_tc_array: ["0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png"],
                day_sc_array: ["0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png"],
                day_zero: 1,
                day_space: 1,
                day_align: hmUI.align.LEFT,
                day_is_character: false,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // 5. Weather Icon
            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                x: 206,
                y: 20,
                image_array: ["0102.png","0103.png","0104.png","0105.png","0106.png","0107.png","0108.png","0109.png","0110.png","0111.png","0112.png","0113.png","0114.png","0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png","0128.png","0129.png","0130.png"],
                image_length: 29,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // 6. Weather Temperature
            normal_weather_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                x: 260,
                y: 20,
                font_array: ["0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png"],
                padding: false,
                h_space: 1,
                unit_sc: '0042.png',
                unit_tc: '0042.png',
                unit_en: '0042.png',
                align_h: hmUI.align.LEFT,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // 7. Digital Clock (Hours & Minutes)
            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                hour_startX: 42,
                hour_startY: 104,
                hour_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
                hour_zero: 1,
                hour_space: 4,
                hour_align: hmUI.align.LEFT,

                minute_startX: 202,
                minute_startY: 104,
                minute_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
                minute_zero: 1,
                minute_space: 4,
                minute_align: hmUI.align.LEFT,

                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // 8. Clock AM/PM
            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                am_x: 330,
                am_y: 122,
                am_sc_path: '0023.png',
                am_en_path: '0023.png',
                pm_x: 330,
                pm_y: 122,
                pm_sc_path: '0024.png',
                pm_en_path: '0024.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // 9. Steps Current Text
            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                x: 82,
                y: 268,
                font_array: ["0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png"],
                padding: false,
                h_space: 1,
                align_h: hmUI.align.LEFT,
                type: hmUI.data_type.STEP,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // 10. Steps Progress Bar
            normal_step_progress_img = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                x: 24,
                y: 328,
                image_array: ["0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png"],
                image_length: 11,
                type: hmUI.data_type.STEP,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // 11. Battery Current Text
            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                x: 270,
                y: 268,
                font_array: ["0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png"],
                padding: false,
                h_space: 1,
                unit_sc: '0041.png',
                unit_tc: '0041.png',
                unit_en: '0041.png',
                align_h: hmUI.align.LEFT,
                type: hmUI.data_type.BATTERY,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // 12. Battery Progress Bar
            normal_battery_progress_img = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                x: 212,
                y: 328,
                image_array: ["0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png"],
                image_length: 11,
                type: hmUI.data_type.BATTERY,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // 13. Heart Rate Text
            normal_heart_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                x: 54,
                y: 394,
                font_array: ["0131.png","0132.png","0133.png","0134.png","0135.png","0136.png","0137.png","0138.png","0139.png","0140.png"],
                padding: false,
                h_space: 1,
                align_h: hmUI.align.LEFT,
                type: hmUI.data_type.HEART,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // 14. Calories Text
            normal_calorie_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                x: 146,
                y: 394,
                font_array: ["0141.png","0142.png","0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png"],
                padding: false,
                h_space: 1,
                align_h: hmUI.align.LEFT,
                type: hmUI.data_type.CAL,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // 15. Distance Text
            normal_distance_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                x: 237,
                y: 394,
                font_array: ["0151.png","0152.png","0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png"],
                padding: false,
                h_space: 1,
                dot_image: '0161.png',
                align_h: hmUI.align.LEFT,
                type: hmUI.data_type.DISTANCE,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenAOD');

            // 16. AOD Clock Time
            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                hour_startX: 42,
                hour_startY: 104,
                hour_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
                hour_zero: 1,
                hour_space: 4,
                hour_align: hmUI.align.LEFT,

                minute_startX: 202,
                minute_startY: 104,
                minute_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
                minute_zero: 1,
                minute_space: 4,
                minute_align: hmUI.align.LEFT,

                show_level: hmUI.show_level.ONLY_AOD,
            });

            // 17. AOD Clock AM/PM
            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                am_x: 330,
                am_y: 122,
                am_sc_path: '0023.png',
                am_en_path: '0023.png',
                pm_x: 330,
                pm_y: 122,
                pm_sc_path: '0024.png',
                pm_en_path: '0024.png',
                show_level: hmUI.show_level.ONLY_AOD,
            });

            //dynamic modify end
        },
        onInit() {
            logger.log('CyberHUD page.js on init invoke');
        },
        build() {
            this.init_view();
            logger.log('CyberHUD page.js on ready invoke');
        },
        onDestroy() {
            logger.log('CyberHUD page.js on destroy invoke');
        }
    });
})();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
}
