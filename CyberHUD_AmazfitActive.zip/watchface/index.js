/*
** Watch_Face_Editor tool v 17.1
** watchface js version v2.1.1
** CyberHUD Futurism Watchface for Amazfit Active
*/

try {
(() => {
    //start of ignored block
    const __$$app$$__ = __$$hmAppManager$$__.currentApp;
    function getApp() {
        return __$$app$$__.app;
    }
    function getCurrentPage() {
        return __$$app$$__.current && __$$app$$__.current.module;
    }
    const __$$module$$__ = __$$app$$__.current;
    const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
    const {px} = __$$app$$__.__globals__;
    const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_CyberHUD');
    //end of ignored block

    // Constants
    const DAYS = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];
    const MONTHS = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
    const WEATHER_DESCRIPTIONS = [
        'CLOUDY', 'RAIN', 'SNOW', 'SUNNY', 'FOG',
        'LIGHT RAIN', 'MODERATE RAIN', 'HEAVY RAIN', 'SHOWERS', 'THUNDER',
        'SLEET', 'DUST', 'WINDY', 'HAZE', 'OVERCAST',
        'LIGHT SNOW', 'MODERATE SNOW', 'HEAVY SNOW', 'SANDSTORM', 'BLIZZARD',
        'PARTLY CLOUDY', 'HEAT WAVE', 'COLD WAVE', 'DRIZZLE', 'STORM',
        'HEAVY STORM', 'SEVERE STORM', 'FREEZING RAIN', 'HAIL'
    ];

    // Sensor references
    let timeSensor = null;
    let stepSensor = null;
    let batterySensor = null;
    let heartSensor = null;
    let calorieSensor = null;
    let distanceSensor = null;
    let sleepSensor = null;
    let weatherSensor = null;

    // Widget references
    let normal_background_bg_img = null;
    let normal_weather_icon = null;
    let normal_digital_clock_img_time = null;
    let normal_digital_clock_img_time_AmPm = null;
    let normal_step_progress_img = null;
    let normal_battery_progress_img = null;

    let textDayOfWeek = null;
    let textDate = null;
    let textWeatherTemp = null;
    let textWeatherDesc = null;
    let text24H = null;

    let textStepsCurrent = null;
    let textStepsGoal = null;
    let textBatteryPercent = null;
    let textBatteryTimeLeft = null;

    let textHeartRate = null;
    let textCalories = null;
    let textDistance = null;
    let textSleep = null;

    let idle_digital_clock_img_time = null;
    let idle_digital_clock_img_time_AmPm = null;

    function updateTimeAndDate() {
        if (!timeSensor) return;
        const dayIdx = timeSensor.week ? (timeSensor.week % 7) : 0;
        const dayName = DAYS[dayIdx] || 'SUNDAY';
        const monthName = MONTHS[(timeSensor.month || 1) - 1] || 'MAY';
        const dayNum = timeSensor.day || 1;
        const yearNum = timeSensor.year || 2025;

        if (textDayOfWeek) {
            textDayOfWeek.setProperty(hmUI.prop.MORE, { text: dayName });
        }
        if (textDate) {
            textDate.setProperty(hmUI.prop.MORE, { text: dayNum + ' ' + monthName + ' ' + yearNum });
        }
    }

    function updateWeather() {
        if (!weatherSensor) return;
        try {
            const data = weatherSensor.getForecastWeather();
            if (data && data.forecastData && data.forecastData.count > 0) {
                const first = data.forecastData.data[0];
                if (first && textWeatherTemp) {
                    textWeatherTemp.setProperty(hmUI.prop.MORE, { text: (first.temp || '--') + '°C' });
                }
                if (first && textWeatherDesc) {
                    const desc = WEATHER_DESCRIPTIONS[first.index] || 'PARTLY CLOUDY';
                    textWeatherDesc.setProperty(hmUI.prop.MORE, { text: desc });
                }
            } else if (textWeatherTemp) {
                textWeatherTemp.setProperty(hmUI.prop.MORE, { text: '26°C' });
                if (textWeatherDesc) textWeatherDesc.setProperty(hmUI.prop.MORE, { text: 'PARTLY CLOUDY' });
            }
        } catch (e) {
            console.log('Weather update error', e);
        }
    }

    function updateSteps() {
        if (!stepSensor) return;
        const cur = stepSensor.current || 0;
        const target = stepSensor.target || 10000;
        if (textStepsCurrent) {
            textStepsCurrent.setProperty(hmUI.prop.MORE, { text: String(cur) });
        }
        if (textStepsGoal) {
            textStepsGoal.setProperty(hmUI.prop.MORE, { text: 'GOAL: ' + target + ' STEPS' });
        }
    }

    function updateBattery() {
        if (!batterySensor) return;
        const cur = batterySensor.current || 0;
        const charging = batterySensor.charging;
        if (textBatteryPercent) {
            textBatteryPercent.setProperty(hmUI.prop.MORE, { text: cur + '%' });
        }
        if (textBatteryTimeLeft) {
            if (charging) {
                textBatteryTimeLeft.setProperty(hmUI.prop.MORE, { text: 'CHARGING...' });
            } else {
                // Estimate remaining battery runtime (e.g. 100% ~ 14 days = 336h, cur% * 3.36h)
                const totalHours = Math.floor(cur * 1.5);
                const hrs = Math.floor(totalHours / 1);
                const mins = Math.floor((cur * 1.5 - hrs) * 60);
                textBatteryTimeLeft.setProperty(hmUI.prop.MORE, { text: 'TIME LEFT ' + hrs + 'h ' + mins + 'm' });
            }
        }
    }

    function updateHeart() {
        if (!heartSensor) return;
        const hr = heartSensor.current || heartSensor.last || 72;
        if (textHeartRate) {
            textHeartRate.setProperty(hmUI.prop.MORE, { text: String(hr > 0 ? hr : '--') });
        }
    }

    function updateCalories() {
        if (!calorieSensor) return;
        const cal = calorieSensor.current || 0;
        if (textCalories) {
            textCalories.setProperty(hmUI.prop.MORE, { text: String(cal) });
        }
    }

    function updateDistance() {
        if (!distanceSensor) return;
        const distM = distanceSensor.current || 0;
        const distKm = (distM / 1000).toFixed(2);
        if (textDistance) {
            textDistance.setProperty(hmUI.prop.MORE, { text: distKm });
        }
    }

    function updateSleep() {
        if (!sleepSensor) return;
        try {
            const info = sleepSensor.getBasicInfo();
            const total = (info && info.totalTime) ? info.totalTime : 450;
            const h = Math.floor(total / 60);
            const m = total % 60;
            if (textSleep) {
                textSleep.setProperty(hmUI.prop.MORE, { text: h + 'h ' + m + 'm' });
            }
        } catch (e) {
            console.log('Sleep update error', e);
        }
    }

    function updateAllSensors() {
        updateTimeAndDate();
        updateWeather();
        updateSteps();
        updateBattery();
        updateHeart();
        updateCalories();
        updateDistance();
        updateSleep();
    }

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
        init_view() {
            console.log('Watch_Face.ScreenNormal init_view');

            // 1. Background
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                src: 'WP_01.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // 2. Weather Icon (IMG_LEVEL with 29 states)
            normal_weather_icon = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                x: 206,
                y: 22,
                image_array: [
                    "0102.png","0103.png","0104.png","0105.png","0106.png","0107.png","0108.png","0109.png","0110.png",
                    "0111.png","0112.png","0113.png","0114.png","0115.png","0116.png","0117.png","0118.png","0119.png",
                    "0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png","0128.png",
                    "0129.png","0130.png"
                ],
                image_length: 29,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // 3. Digital Clock (Hours Cyan 0003..0012, Minutes Purple 0013..0022)
            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                hour_startX: 44,
                hour_startY: 108,
                hour_array: [
                    "0003.png","0004.png","0005.png","0006.png","0007.png",
                    "0008.png","0009.png","0010.png","0011.png","0012.png"
                ],
                hour_zero: 1,
                hour_space: 4,
                hour_align: hmUI.align.LEFT,

                minute_startX: 202,
                minute_startY: 108,
                minute_array: [
                    "0013.png","0014.png","0015.png","0016.png","0017.png",
                    "0018.png","0019.png","0020.png","0021.png","0022.png"
                ],
                minute_zero: 1,
                minute_space: 4,
                minute_align: hmUI.align.LEFT,

                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // 4. Clock AM / PM
            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                am_x: 336,
                am_y: 142,
                am_sc_path: '0023.png',
                am_en_path: '0023.png',
                pm_x: 336,
                pm_y: 142,
                pm_sc_path: '0024.png',
                pm_en_path: '0024.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // 5. Steps Segmented Progress Bar (11 levels)
            normal_step_progress_img = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                x: 24,
                y: 328,
                image_array: [
                    "0091.png","0092.png","0093.png","0094.png","0095.png","0096.png",
                    "0097.png","0098.png","0099.png","0100.png","0101.png"
                ],
                image_length: 11,
                type: hmUI.data_type.STEP,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // 6. Battery Smooth Progress Bar (11 levels)
            normal_battery_progress_img = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                x: 212,
                y: 328,
                image_array: [
                    "0080.png","0081.png","0082.png","0083.png","0084.png","0085.png",
                    "0086.png","0087.png","0088.png","0089.png","0090.png"
                ],
                image_length: 11,
                type: hmUI.data_type.BATTERY,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // 7. Header Text Widgets
            textDayOfWeek = hmUI.createWidget(hmUI.widget.TEXT, {
                x: 60,
                y: 22,
                w: 130,
                h: 26,
                color: 0xFFFFFF,
                text_size: 16,
                align_h: hmUI.align.LEFT,
                align_v: hmUI.align.CENTER_V,
                text: 'SUNDAY',
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            textDate = hmUI.createWidget(hmUI.widget.TEXT, {
                x: 60,
                y: 48,
                w: 130,
                h: 22,
                color: 0x00E5FF,
                text_size: 13,
                align_h: hmUI.align.LEFT,
                align_v: hmUI.align.CENTER_V,
                text: '25 MAY 2025',
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            textWeatherTemp = hmUI.createWidget(hmUI.widget.TEXT, {
                x: 260,
                y: 22,
                w: 90,
                h: 28,
                color: 0xFFFFFF,
                text_size: 20,
                align_h: hmUI.align.LEFT,
                align_v: hmUI.align.CENTER_V,
                text: '26°C',
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            textWeatherDesc = hmUI.createWidget(hmUI.widget.TEXT, {
                x: 260,
                y: 50,
                w: 110,
                h: 18,
                color: 0x8291A0,
                text_size: 9,
                align_h: hmUI.align.LEFT,
                align_v: hmUI.align.CENTER_V,
                text: 'PARTLY CLOUDY',
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            text24H = hmUI.createWidget(hmUI.widget.TEXT, {
                x: 338,
                y: 166,
                w: 32,
                h: 18,
                color: 0x8291A0,
                text_size: 11,
                align_h: hmUI.align.LEFT,
                align_v: hmUI.align.CENTER_V,
                text: '24H',
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // 8. Steps Card Text Widgets
            textStepsCurrent = hmUI.createWidget(hmUI.widget.TEXT, {
                x: 82,
                y: 264,
                w: 104,
                h: 36,
                color: 0xFFFFFF,
                text_size: 26,
                align_h: hmUI.align.LEFT,
                align_v: hmUI.align.CENTER_V,
                text: '7645',
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            textStepsGoal = hmUI.createWidget(hmUI.widget.TEXT, {
                x: 82,
                y: 302,
                w: 104,
                h: 18,
                color: 0x8291A0,
                text_size: 10,
                align_h: hmUI.align.LEFT,
                align_v: hmUI.align.CENTER_V,
                text: 'GOAL: 10000 STEPS',
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // 9. Battery Card Text Widgets
            textBatteryPercent = hmUI.createWidget(hmUI.widget.TEXT, {
                x: 270,
                y: 264,
                w: 104,
                h: 36,
                color: 0xFFFFFF,
                text_size: 26,
                align_h: hmUI.align.LEFT,
                align_v: hmUI.align.CENTER_V,
                text: '87%',
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            textBatteryTimeLeft = hmUI.createWidget(hmUI.widget.TEXT, {
                x: 270,
                y: 302,
                w: 104,
                h: 18,
                color: 0xC864F0,
                text_size: 10,
                align_h: hmUI.align.LEFT,
                align_v: hmUI.align.CENTER_V,
                text: 'TIME LEFT 12h 45m',
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // 10. Bottom Health Row Numbers
            textHeartRate = hmUI.createWidget(hmUI.widget.TEXT, {
                x: 54,
                y: 388,
                w: 48,
                h: 26,
                color: 0xFF325A,
                text_size: 18,
                align_h: hmUI.align.LEFT,
                align_v: hmUI.align.CENTER_V,
                text: '72',
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            textCalories = hmUI.createWidget(hmUI.widget.TEXT, {
                x: 146,
                y: 388,
                w: 48,
                h: 26,
                color: 0xFFA500,
                text_size: 18,
                align_h: hmUI.align.LEFT,
                align_v: hmUI.align.CENTER_V,
                text: '512',
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            textDistance = hmUI.createWidget(hmUI.widget.TEXT, {
                x: 237,
                y: 388,
                w: 48,
                h: 26,
                color: 0x00E676,
                text_size: 18,
                align_h: hmUI.align.LEFT,
                align_v: hmUI.align.CENTER_V,
                text: '5.62',
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            textSleep = hmUI.createWidget(hmUI.widget.TEXT, {
                x: 329,
                y: 390,
                w: 48,
                h: 24,
                color: 0x64B4F6,
                text_size: 14,
                align_h: hmUI.align.LEFT,
                align_v: hmUI.align.CENTER_V,
                text: '7h 30m',
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // 11. Sensor Initialization & Event Subscriptions
            try {
                timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
                stepSensor = hmSensor.createSensor(hmSensor.id.STEP);
                batterySensor = hmSensor.createSensor(hmSensor.id.BATTERY);
                heartSensor = hmSensor.createSensor(hmSensor.id.HEART);
                calorieSensor = hmSensor.createSensor(hmSensor.id.CALORIE);
                distanceSensor = hmSensor.createSensor(hmSensor.id.DISTANCE);
                sleepSensor = hmSensor.createSensor(hmSensor.id.SLEEP);
                weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

                if (timeSensor) {
                    timeSensor.addEventListener(hmSensor.event.MINUTEEND, () => {
                        updateTimeAndDate();
                        updateWeather();
                    });
                }
                if (stepSensor) {
                    stepSensor.addEventListener(hmSensor.event.CHANGE, updateSteps);
                }
                if (batterySensor) {
                    batterySensor.addEventListener(hmSensor.event.CHANGE, updateBattery);
                }
                if (heartSensor) {
                    heartSensor.addEventListener(hmSensor.event.CURRENT, updateHeart);
                }
                if (calorieSensor) {
                    calorieSensor.addEventListener(hmSensor.event.CHANGE, updateCalories);
                }
                if (distanceSensor) {
                    distanceSensor.addEventListener(hmSensor.event.CHANGE, updateDistance);
                }
            } catch (err) {
                console.log('Sensor init error', err);
            }

            // Initial Sensor Read
            updateAllSensors();

            // 12. Screen Resume Delegate
            hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                resume_call: () => {
                    console.log('CyberHUD resume_call');
                    updateAllSensors();
                },
                pause_call: () => {
                    console.log('CyberHUD pause_call');
                }
            });

            // 13. AOD Clock Screen
            console.log('Watch_Face.ScreenAOD');
            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                hour_startX: 44,
                hour_startY: 108,
                hour_array: [
                    "0003.png","0004.png","0005.png","0006.png","0007.png",
                    "0008.png","0009.png","0010.png","0011.png","0012.png"
                ],
                hour_zero: 1,
                hour_space: 4,
                hour_align: hmUI.align.LEFT,

                minute_startX: 202,
                minute_startY: 108,
                minute_array: [
                    "0013.png","0014.png","0015.png","0016.png","0017.png",
                    "0018.png","0019.png","0020.png","0021.png","0022.png"
                ],
                minute_zero: 1,
                minute_space: 4,
                minute_align: hmUI.align.LEFT,

                show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                am_x: 336,
                am_y: 142,
                am_sc_path: '0023.png',
                am_en_path: '0023.png',
                pm_x: 336,
                pm_y: 142,
                pm_sc_path: '0024.png',
                pm_en_path: '0024.png',
                show_level: hmUI.show_level.ONLY_AOD,
            });
        },
        onInit() {
            logger.log('CyberHUD page.js on init invoke');
        },
        build() {
            this.init_view();
            logger.log('CyberHUD page.js on ready invoke');
        },
        onDestroy() {
            logger.log('CyberHUD page.js on destroy invoke');
        }
    });
})();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/[\r\n]/).forEach(i => console.log('error stack', i));
}
