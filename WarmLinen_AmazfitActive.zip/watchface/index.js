/*
** Watch_Face_Editor tool v 17.1
** watchface js version v2.1.1
** Warm Linen Minimal Watchface V2
*/

try {
(() => {
    //start of ignored block
    const __$$app$$__ = __$$hmAppManager$$__.currentApp;
    function getApp() {
        return __$$app$$__.app;
    }
    function getCurrentPage() {
        return __$$app$$__.current && __$$app$$__.current.module;
    }
    const __$$module$$__ = __$$app$$__.current;
    const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
    const {px} = __$$app$$__.__globals__;
    const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_WarmLinen');
    //end of ignored block

    //dynamic modify start
    let normal_background_bg_img = '';
    let normal_date_img_date_week_img = '';
    let normal_date_img_date_day = '';
    let normal_date_img_date_month_img = '';
    let normal_weather_icon = '';
    let normal_weather_temp = '';
    let normal_digital_clock_img_time = '';
    let normal_digital_clock_img_time_AmPm = '';
    let normal_step_current_text_img = '';
    let normal_step_progress_img = '';
    let normal_battery_text_text_img = '';
    let normal_battery_progress_img = '';
    let idle_digital_clock_img_time = '';
    let idle_digital_clock_img_time_AmPm = '';
    //dynamic modify end

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
        init_view() {
            console.log('Watch_Face.ScreenNormal');

            // 1. Background WP_01.png
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                src: 'WP_01.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // 2. Weekday (Top-Left, Col 1 centered at 65, width 92 -> x=19)
            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                x: 19,
                y: 48,
                week_en: ["0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png"],
                week_tc: ["0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png"],
                week_sc: ["0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png"],
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // 3. Dynamic Week Number Text (Top-Left)
            const normal_week_num_text = hmUI.createWidget(hmUI.widget.TEXT, {
                x: 10,
                y: 72,
                w: 110,
                h: 20,
                color: 0x5E828E,
                text_size: 13,
                text_style: hmUI.text_style.NONE,
                align_h: hmUI.align.CENTER_H,
                align_v: hmUI.align.CENTER_V,
                text: 'WEEK --',
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function updateWeekNum() {
                try {
                    const now = new Date();
                    const d = new Date(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate()));
                    const dayNum = d.getUTCDay() || 7;
                    d.setUTCDate(d.getUTCDate() + 4 - dayNum);
                    const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
                    const weekNo = Math.ceil((((d - yearStart) / 86400000) + 1) / 7);
                    normal_week_num_text.setProperty(hmUI.prop.MORE, {
                        text: 'WEEK ' + weekNo
                    });
                } catch (e) {
                    console.log('Week num update error', e);
                }
            }
            updateWeekNum();

            // 4. Day of Month (Top-Center, Col 2 centered at 195, width 40 -> x=175)
            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
                day_startX: 175,
                day_startY: 34,
                day_en_array: ["0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png"],
                day_tc_array: ["0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png"],
                day_sc_array: ["0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png"],
                day_zero: 1,
                day_space: 2,
                day_align: hmUI.align.LEFT,
                day_is_character: false,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // 5. Month (Top-Center, Col 2 centered at 195, width 76 -> x=157)
            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
                month_startX: 157,
                month_startY: 70,
                month_en_array: ["0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png"],
                month_tc_array: ["0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png"],
                month_sc_array: ["0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png"],
                month_is_character: true,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // 6. Weather Condition Icon (Top-Right, Col 3 centered at 325, width 42 -> x=304)
            normal_weather_icon = hmUI.createWidget(hmUI.widget.IMG, {
                x: 304,
                y: 36,
                src: '0105.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let weatherSensor = null;
            function updateWeatherIcon() {
                try {
                    if (!weatherSensor) {
                        weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
                    }
                    if (weatherSensor && weatherSensor.getForecastWeather) {
                        const forecast = weatherSensor.getForecastWeather();
                        if (forecast && forecast.forecastData) {
                            const list = forecast.forecastData.data || forecast.forecastData;
                            if (list && list.length > 0) {
                                const idx = list[0].index;
                                if (idx !== undefined && idx >= 0 && idx <= 28) {
                                    const iconName = '0' + (idx + 102) + '.png';
                                    normal_weather_icon.setProperty(hmUI.prop.SRC, iconName);
                                }
                            }
                        }
                    }
                } catch (e) {
                    console.log('Weather icon update error', e);
                }
            }
            updateWeatherIcon();

            // 7. Weather Temperature (Top-Right, Col 3 centered at 325, width ~36 -> x=307)
            normal_weather_temp = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                x: 307,
                y: 74,
                font_array: ["0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png"],
                h_space: 1,
                unit_en: '0042.png',
                unit_tc: '0042.png',
                unit_sc: '0042.png',
                align_h: hmUI.align.LEFT,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // 8. Digital Clock (Hours & Minutes, Tabular 54px width, perfectly symmetrical)
            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                hour_startX: 72,
                hour_startY: 135,
                hour_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
                hour_zero: 1,
                hour_space: 4,
                hour_align: hmUI.align.LEFT,

                minute_startX: 206,
                minute_startY: 135,
                minute_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
                minute_zero: 1,
                minute_space: 4,
                minute_align: hmUI.align.LEFT,

                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // 9. Clock AM / PM
            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                am_x: 324,
                am_y: 226,
                am_sc_path: '0023.png',
                am_en_path: '0023.png',
                pm_x: 324,
                pm_y: 226,
                pm_sc_path: '0024.png',
                pm_en_path: '0024.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // 10. Card 1 Steps Text
            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                x: 90,
                y: 346,
                font_array: ["0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png"],
                padding: false,
                h_space: 1,
                align_h: hmUI.align.LEFT,
                type: hmUI.data_type.STEP,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // 11. Card 1 Steps Progress Bar (width 125px)
            normal_step_progress_img = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                x: 35,
                y: 388,
                image_array: ["0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png"],
                image_length: 11,
                type: hmUI.data_type.STEP,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // 12. Card 2 Battery Text
            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                x: 285,
                y: 346,
                font_array: ["0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png"],
                padding: false,
                h_space: 1,
                unit_sc: '0041.png',
                unit_tc: '0041.png',
                unit_en: '0041.png',
                align_h: hmUI.align.LEFT,
                type: hmUI.data_type.BATTERY,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // 13. Card 2 Battery Progress Bar (width 125px)
            normal_battery_progress_img = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                x: 230,
                y: 388,
                image_array: ["0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png"],
                image_length: 11,
                type: hmUI.data_type.BATTERY,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // 14. Event listeners & wake delegate
            const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            if (timeSensor && timeSensor.addEventListener) {
                timeSensor.addEventListener(timeSensor.event.MINUTEEND, () => {
                    updateWeekNum();
                    updateWeatherIcon();
                });
            }

            hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                resume_call: () => {
                    updateWeekNum();
                    updateWeatherIcon();
                }
            });

            // 15. AOD Clock Screen
            console.log('Watch_Face.ScreenAOD');
            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                hour_startX: 72,
                hour_startY: 135,
                hour_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
                hour_zero: 1,
                hour_space: 4,
                hour_align: hmUI.align.LEFT,

                minute_startX: 206,
                minute_startY: 135,
                minute_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
                minute_zero: 1,
                minute_space: 4,
                minute_align: hmUI.align.LEFT,

                show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                am_x: 324,
                am_y: 226,
                am_sc_path: '0023.png',
                am_en_path: '0023.png',
                pm_x: 324,
                pm_y: 226,
                pm_sc_path: '0024.png',
                pm_en_path: '0024.png',
                show_level: hmUI.show_level.ONLY_AOD,
            });
        },
        onInit() {
            logger.log('WarmLinen page.js on init invoke');
        },
        build() {
            this.init_view();
            logger.log('WarmLinen page.js on ready invoke');
        },
        onDestroy() {
            logger.log('WarmLinen page.js on destroy invoke');
        }
    });
})();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
}
